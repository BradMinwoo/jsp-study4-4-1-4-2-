package com.study.common.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class IPCheckFilter implements Filter{
	private Map<String,Boolean> denyIpMap=new HashMap<String, Boolean>();
	
	//필더 처음 실행시에만 한번 실행
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		//192.168.1.24:8080/study3/아무거나.. free/freeList.wow
		
			denyIpMap.put("192.168.1.25", false);
			denyIpMap.put("192.168.1.26", false);
			denyIpMap.put("192.168.1.30", false);
			denyIpMap.put("192.168.1.3", false);
			denyIpMap.put("192.168.1.37", false);
			denyIpMap.put("192.168.1.41", false);
			denyIpMap.put("192.168.1.42", false);
			denyIpMap.put("192.168.1.11", false);
			denyIpMap.put("192.168.1.19", false);
	}

	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req=(HttpServletRequest)request;
		System.out.println(req.getRemoteAddr()+"Aaa");
		if(denyIpMap.get(req.getRemoteAddr())!=null) {
			HttpServletResponse resp=(HttpServletResponse)response;
			resp.setContentType("text/html; charset=utf-8"); 
			PrintWriter out=resp.getWriter();
			out.print("<html><body> <h1> 당신은 접근 할  수 없는 사람입니다 </h1></body></html>");
			return;
		}else {
			chain.doFilter(request, response);
		}
		
	}
	
	
	
	

}
