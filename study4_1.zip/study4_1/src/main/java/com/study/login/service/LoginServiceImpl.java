package com.study.login.service;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.study.common.util.MybatisSqlSessionFactory;
import com.study.login.vo.UserVO;
import com.study.member.dao.IMemberDao;
import com.study.member.vo.MemberVO;

public class LoginServiceImpl implements ILoginService {
	SqlSessionFactory sqlSessionFactory = MybatisSqlSessionFactory.getSqlSessionFactory();

	@Override
	public UserVO getUser(String memId) {
		try (SqlSession session = sqlSessionFactory.openSession(true)) {
			IMemberDao memberDao = session.getMapper(IMemberDao.class);
			MemberVO member = memberDao.getMember(memId);
			if (member != null) {
				UserVO user = new UserVO();
				user.setUserId(memId);
				user.setUserName(member.getMemName());
				user.setUserPass(member.getMemPass());
				user.setUserRole("MEMBER");
				return user;
			} else {
				return null;
			}
		}
	}
}
