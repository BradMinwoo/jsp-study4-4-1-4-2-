package com.study.free.web;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.study.code.service.CommCodeServiceImpl;
import com.study.code.service.ICommCodeService;
import com.study.code.vo.CodeVO;
import com.study.free.service.FreeBoardServiceImpl;
import com.study.free.service.IFreeBoardService;
import com.study.free.vo.FreeBoardSearchVO;
import com.study.free.vo.FreeBoardVO;

@Controller
public class FreeBoardController {
	@Inject
	IFreeBoardService freeBoardService;
	@Inject 
	ICommCodeService codeService;
	
	
	@RequestMapping("/free/freeList.wow")
	public String freeBoardList(HttpServletRequest req) {
		FreeBoardSearchVO searchVO=new FreeBoardSearchVO();
		try {
			BeanUtils.populate(searchVO, req.getParameterMap());
		} catch (IllegalAccessException | InvocationTargetException e) {
			System.out.println("파라미터가 세팅이 안되네...");
			e.printStackTrace();
		}
		req.setAttribute("searchVO", searchVO);
		List<FreeBoardVO> freeBoardList = freeBoardService.getBoardList(searchVO);
		req.setAttribute("freeBoardList", freeBoardList);
		List<CodeVO> cateList=codeService.getCodeListByParent("BC00");
		req.setAttribute("cateList", cateList);
		return "free/freeList";
	}
	
	
	
}
