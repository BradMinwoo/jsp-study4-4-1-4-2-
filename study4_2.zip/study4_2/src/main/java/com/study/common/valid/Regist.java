package com.study.common.valid;

public interface Regist {

}
