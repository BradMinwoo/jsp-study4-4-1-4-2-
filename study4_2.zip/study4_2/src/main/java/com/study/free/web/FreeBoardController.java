package com.study.free.web;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import javax.crypto.Mac;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.groups.Default;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.study.code.service.CommCodeServiceImpl;
import com.study.code.service.ICommCodeService;
import com.study.code.vo.CodeVO;
import com.study.common.valid.Modify;
import com.study.common.vo.ResultMessageVO;
import com.study.exception.BizNotEffectedException;
import com.study.exception.BizNotFoundException;
import com.study.exception.BizPasswordNotMatchedException;
import com.study.free.service.FreeBoardServiceImpl;
import com.study.free.service.IFreeBoardService;
import com.study.free.vo.FreeBoardSearchVO;
import com.study.free.vo.FreeBoardVO;

import aj.org.objectweb.asm.Attribute;

@Controller
public class FreeBoardController {
	@Inject
	IFreeBoardService freeBoardService;
	@Inject 
	ICommCodeService codeService;
	
	//edit 이랑 form,list에는cateList가 공통으로  model에 담겨요.... 코드 중복처리 처리할수 있음. 
	@ModelAttribute("cateList")
	public List<CodeVO> cateList(){
		return codeService.getCodeListByParent("BC00");
	}
	
	@RequestMapping("/free/freeList.wow")
	public String freeBoardList(Model model,@ModelAttribute("searchVO")FreeBoardSearchVO searchVO) {
		// 모델 어트리뷰가"searchVO"함으로써  jsp에서 EL문에서 사용 가능
		
		
		List<FreeBoardVO> freeBoardList = freeBoardService.getBoardList(searchVO);
		model.addAttribute("freeBoardList", freeBoardList);
		
		return "free/freeList";
	}
	
	@RequestMapping(value="/free/freeView.wow")
	public String freeBoardView(Model model,@RequestParam(required = true, name = "boNo") int boNo) {
			try{
				FreeBoardVO freeBoard=freeBoardService.getBoard(boNo);
				model.addAttribute("freeBoard", freeBoard);
				freeBoardService.increaseHit(boNo);
			}catch (BizNotFoundException enf){
				ResultMessageVO resultMessageVO= new ResultMessageVO();
				resultMessageVO.messageSetting(false, "글Notfound", "해당 글이 없습니다",
						"/free/freeList.wow", "목록으로");
				return "common/message";
			}catch (BizNotEffectedException ene){
				ResultMessageVO resultMessageVO= new ResultMessageVO();
				resultMessageVO.messageSetting(false, "글NotEffected", "업데이트에 실패했습니다",
						"/free/freeList.wow", "목록으로");
				return "common/message";
			}
			return "free/freeView";
	}

//	@RequestMapping("/free/freeEdit.wow")
//	public ModelAndView freeBoardEdit(int boNo) {
//		ModelAndView mav=new ModelAndView();
//		try{
//			FreeBoardVO freeBoard=freeBoardService.getBoard(boNo);
//			mav.addObject( "freeBoard",freeBoard);
//		}catch (BizNotFoundException enf){
//			ResultMessageVO resultMessageVO= new ResultMessageVO();
//			resultMessageVO.messageSetting(false, "글Notfound", "해당 글이 없습니다",
//					"/free/freeList.wow", "목록으로");
//			mav.addObject( "resultMessageVO",resultMessageVO);
//			mav.setViewName("common/message");
//		}
//		List<CodeVO> cateList=codeService.getCodeListByParent("BC00");
//		mav.addObject("cateList", cateList);
//		mav.setViewName("free/freeEdit");

//		return mav;
//	}
	@RequestMapping("/free/freeEdit.wow")
	public String freeBoardEdit(Model model, int boNo) {
		try{
			FreeBoardVO freeBoard=freeBoardService.getBoard(boNo);
			model.addAttribute( "freeBoard",freeBoard);
		}catch (BizNotFoundException enf){
			ResultMessageVO resultMessageVO= new ResultMessageVO();
			resultMessageVO.messageSetting(false, "글Notfound", "해당 글이 없습니다",
					"/free/freeList.wow", "목록으로");
			model.addAttribute( "resultMessageVO",resultMessageVO);
				return "common/message";
		}
		
		return "free/freeEdit";
	}
	
	@RequestMapping(value="/free/freeModify.wow", method = RequestMethod.POST)
	public  String freeBoardModify(Model model,
			@Validated(value= {Modify.class, Default.class}) @ModelAttribute("freeBoard")FreeBoardVO freeBoardVO,
			BindingResult error) {
		if(error.hasErrors()) {
			return "free/freeEdit";
		}
		ResultMessageVO resultMessageVO=new ResultMessageVO();
		try {
			freeBoardService.modifyBoard(freeBoardVO);
			resultMessageVO.messageSetting(true, "수정", "수정성공"
				,"/free/freeList.wow" , "목록으로");
		} catch (BizNotFoundException enf) {
			resultMessageVO.messageSetting(false, "글Notfound", "해당 글이 없습니다",
					"/free/freeList.wow", "목록으로");
		} catch (BizPasswordNotMatchedException epm) {
			resultMessageVO.messageSetting(false, "비밀번호틀림", "글쓸때의 비밀번호랑 다릅니다",
					"/free/freeList.wow", "목록으로");
		} catch (BizNotEffectedException ene) {
			resultMessageVO.messageSetting(false, "글NotEffected", "업데이트에 실패했습니다",
					"/free/freeList.wow", "목록으로");
		}
		model.addAttribute("resultMessageVO", resultMessageVO);
		return "common/message";
	}
	
	
	@RequestMapping("/free/freeForm.wow")
	// url
	public  String freeBoardForm(Model model, 
			@ModelAttribute("freeBoard")FreeBoardVO freeBoard) {
//		model.addAttribute("freeBoard",new FreeBoardVO())
		return "free/freeForm";
		//보이는 화면 = jsp
	}
	
	@PostMapping(value="/free/freeRegist.wow")
	public  String freeBoardRegist(Model model,
			@Validated() @ModelAttribute("freeBoard")FreeBoardVO freeBoard,
			BindingResult error) {
		// 주의할 점 : 검사결과 객체는 반드시 반드시 검사대상객체 바로 뒤에.!!!!
		// FreeBoardVO는 사용자가 넘긴 데이터인데 이를 검사하고싶다...
		// CASE1: 검사해서 문제가 있는 경우=>다시 freeForm.jsp로 가야지
		if(error.hasErrors()) {
			return "free/freeForm";
		}
		
		// CASE2: 검사해서 문제가 없는 경우 => 기존코드 그대로 실행
		
		ResultMessageVO resultMessageVO=new ResultMessageVO();
		try {
			freeBoardService.registBoard(freeBoard);
			resultMessageVO.messageSetting(true, "등록", "등록성공", "/free/freeList.wow"
					 ,"목록으로");
		} catch (BizNotEffectedException ebe) {
			resultMessageVO.messageSetting(false, "실패", "업데이트실패", "/free/freeList.wow"
					 ,"목록으로");
		}
		model.addAttribute("resultMessageVO", resultMessageVO);
		return "common/message";
	
	}
	
	/*
	 * private boolean isHaveProblemFreeBoardRegist(FreeBoardVO freeBoard) {
	 * if(freeBoard.getBoWriter().isEmpty()) return true;
	 * if(freeBoard.getBoCategory().isEmpty()) return true;
	 * if(freeBoard.getBoPass().isEmpty() || freeBoard.getBoPass().length()<4)
	 * return true; // 나머지도 이렇ㄱ 하나하나 검사하면되겠지....ㄴ return false; }
	 */
	
	@PostMapping(value="/free/freeDelete.wow")
	public  String freeBoardDelete(Model model, @ModelAttribute("freeBoard")FreeBoardVO freeBoardVO) {
		ResultMessageVO resultMessageVO=new ResultMessageVO();
		try {
			freeBoardService.removeBoard(freeBoardVO);
			resultMessageVO.messageSetting(true, "삭제", "삭제성공"
					,"/free/freeList.wow" , "목록으로");
		}catch (BizNotFoundException enf) {
			resultMessageVO.messageSetting(false, "글Notfound", "해당 글이 없습니다",
					"/free/freeList.wow", "목록으로");
		} catch (BizPasswordNotMatchedException epm) {
			resultMessageVO.messageSetting(false, "비밀번호틀림", "글쓸때의 비밀번호랑 다릅니다",
					"/free/freeList.wow", "목록으로");
		} catch (BizNotEffectedException ene) {
			resultMessageVO.messageSetting(false, "글NotEffected", "업데이트에 실패했습니다",
					"/free/freeList.wow", "목록으로");
		}
		model.addAttribute("resultMessageVO", resultMessageVO);
		return "common/message";
	}


		
	
	
	
}
	

