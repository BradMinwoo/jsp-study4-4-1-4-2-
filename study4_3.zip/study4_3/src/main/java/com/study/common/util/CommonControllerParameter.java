package com.study.common.util;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class CommonControllerParameter {
	
	@Pointcut("execution(public * com.study.*.web..*(*,..))")
	private void publicTarget() {		
	}
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Around("publicTarget()")
	public Object logConsole(ProceedingJoinPoint joinPoint) throws Throwable{
		Signature sig = joinPoint.getSignature();
		logger.info("클래스 : {}", joinPoint.getTarget().getClass().getSimpleName());
		logger.info("메소드 : {}", sig.getName());
		
		Object[] parameterArr = joinPoint.getArgs(); // 이 메소드는 para가 없을 때 null 값을 리턴하지 않는다. -> length = 0 인 arr을 반환한다.  = []  
		// 애초에 execution 에서 para 2개이상인 method를 받았기 때문에, null_check 안해도 된다. 
		for(Object parameter : parameterArr) {
			//Model이 출력되는데.. Model은 보지않고 싶다 !((그 다음 선언한 searchVO...뭐 다른것들..이 다음에 나오니까..) 
			if(parameter != null && !parameter.getClass().getSimpleName().equals("BindingAwareModelMap")) {
				logger.info("파라미터 타입 : {}", parameter.getClass().getSimpleName());
				logger.info("파라미터 값 : {} ", parameter);
			}
		}
//		System.out.println("파라미터 : " + Arrays.toString(joinPoint.getArgs()));
		
		try {
			Object obj = joinPoint.proceed();		// ? 
			return obj;
		} finally{
			
//			 안씁니다. 서비스에서 무언가 ... 할때..??
//			System.out.println("클래스 : " + joinPoint.getTarget().getClass().getSimpleName());
//			System.out.println("메소드 : " + sig.getName());
//			System.out.println("파라미터 : " + Arrays.toString(joinPoint.getArgs()));
		}
		
		
		
		
		
	}
	
	
	

}