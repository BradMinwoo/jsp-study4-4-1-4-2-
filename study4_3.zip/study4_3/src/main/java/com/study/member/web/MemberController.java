package com.study.member.web;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.study.code.service.CommCodeServiceImpl;
import com.study.code.service.ICommCodeService;
import com.study.code.vo.CodeVO;
import com.study.common.valid.Modify;
import com.study.common.vo.ResultMessageVO;
import com.study.exception.BizDuplicateKeyException;
import com.study.exception.BizNotEffectedException;
import com.study.exception.BizNotFoundException;
import com.study.free.vo.FreeBoardVO;
import com.study.member.service.IMemberService;
import com.study.member.service.MemberServiceImpl;
import com.study.member.vo.MemberSearchVO;
import com.study.member.vo.MemberVO;

@Controller
public class MemberController {
	@Inject 
	IMemberService memberService;
	@Inject
	ICommCodeService codeService;
	// 1.codeService로 얻는 코드는 @ModelAtrribute()메소드로 만들어주세요
	// 2. VO에는 @ModelAttribute()붙여줍니다.
	// 3. @RequestMapping(Post,GetMapping 전부) retrun은 String
	// 4. 수정, 삭제, 등록은  post방식만 허용

	@ModelAttribute("jobList")
	public List<CodeVO> jobList(){
		return codeService.getCodeListByParent("JB00");
	}
	@ModelAttribute("hobbyList")
	public List<CodeVO> hobbyList(){
		return codeService.getCodeListByParent("HB00");
	}
	
	
	@RequestMapping("/member/memberList.wow")
	public String memberList(Model model,@ModelAttribute("searchVO")MemberSearchVO searchVO) {
		List<MemberVO> memberList=memberService.getMemberList(searchVO);
		model.addAttribute("memberList", memberList);
		
		return "member/memberList";
	}
	
	@RequestMapping("/member/memberView.wow")
	public String memberView(Model model,@RequestParam(required = true, name="memId") String memId) {
		try{
			MemberVO member=memberService.getMember(memId);
			model.addAttribute("member", member);
		}catch (BizNotFoundException enf){
			ResultMessageVO resultMessageVO= new ResultMessageVO();
			resultMessageVO.messageSetting(false, "회원Notfound", "해당 회원이 없습니다",
				"/member/memberList.wow", "목록으로");
			model.addAttribute("resultMessageVO", resultMessageVO);
			return "common/message";
	}
	return "member/memberView";
	}
	
	@RequestMapping("/member/memberEdit.wow")
	public String memberEdit(Model model,String memId) {
		try {
			MemberVO member = memberService.getMember(memId);
			model.addAttribute("member", member);
		} catch (BizNotFoundException enf) {
			ResultMessageVO resultMessageVO= new ResultMessageVO();
			resultMessageVO.messageSetting(false, "회원Notfound", "해당 회원이 없습니다",
					"/member/memberList.wow", "목록으로");
			model.addAttribute("resultMessageVO", resultMessageVO);
			return "common/message";
		}

		return "member/memberEdit";
	
	}
	
	@PostMapping(value="/member/memberModify.wow")
	public String memberModify(Model model,
			@Validated(value= {Modify.class}) @ModelAttribute("memberVO")MemberVO memberVO,
			BindingResult error) {
		if(error.hasErrors()) {
			return "member/memberEdit";
		}
		ResultMessageVO resultMessageVO = new ResultMessageVO();
		try {
			memberService.modifyMember(memberVO);
			resultMessageVO.messageSetting(true, "수정", "수정성공", "/member/memberList.wow", "목록으로");
		} catch (BizNotEffectedException ene) {
			resultMessageVO.messageSetting(false, "회원NotEffected", "업데이트에 실패했습니다", "/member/memberList.wow", "목록으로");
		} catch (BizNotFoundException enf) {
			resultMessageVO.messageSetting(false, "회원Notfound", "해당 회원이 없습니다", "/member/memberList.wow", "목록으로");
		}
		model.addAttribute("resultMessageVO",resultMessageVO);
		return "common/message";
	}

	
	@PostMapping(value="/member/memberDelete.wow")
	public String memberDelete(Model model,@ModelAttribute("memberVO")MemberVO memberVO) {
		ResultMessageVO resultMessageVO = new ResultMessageVO();
		try {
			memberService.removeMember(memberVO);
			resultMessageVO.messageSetting(true, "삭제", "삭제성공", "/member/memberList.wow", "목록으로");
		} catch (BizNotEffectedException ene) {
			resultMessageVO.messageSetting(false, "회원NotEffected", "업데이트에 실패했습니다", "/member/memberList.wow", "목록으로");
		} catch (BizNotFoundException enf) {
			resultMessageVO.messageSetting(false, "회원Notfound", "해당 회원이 없습니다", "/member/memberList.wow", "목록으로");
		}
		model.addAttribute("resultMessageVO",resultMessageVO);
		return "common/message";
	}
	
	
	@RequestMapping("/member/memberForm.wow")
	public  String memberForm(Model model, @ModelAttribute("memberVO")MemberVO memberVO) {
		return "member/memberForm";
	}
	
	@PostMapping(value="/member/memberRegist.wow")
	public String memberRegist(Model model,
			@Validated()@ModelAttribute("memberVO")MemberVO memberVO,
			BindingResult error) {
		if(error.hasErrors()) {
			return "member/memberForm";
		}
		ResultMessageVO resultMessageVO = new ResultMessageVO();
		try {
			memberService.registMember(memberVO);
			resultMessageVO.messageSetting(true, "등록", "등록성공", "/member/memberList.wow", "목록으로");
		} catch (BizNotEffectedException ene) {
			resultMessageVO.messageSetting(false, "회원NotEffected", "업데이트에 실패했습니다", "/member/memberList.wow", "목록으로");
		} catch (BizDuplicateKeyException ede) {
			resultMessageVO.messageSetting(false, "회원중복아이디", "insert에 실패했습니다", "/member/memberList.wow", "목록으로");
		}
		model.addAttribute("resultMessageVO",resultMessageVO);
		return "common/message";
	}

}
