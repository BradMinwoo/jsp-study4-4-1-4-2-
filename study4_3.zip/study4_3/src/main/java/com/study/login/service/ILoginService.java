package com.study.login.service;
import com.study.login.vo.UserVO;
public interface ILoginService {
	public UserVO getUser(String memId);
}
